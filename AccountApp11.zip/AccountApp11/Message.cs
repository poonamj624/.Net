﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp11
{
    internal class Message
    {
        public static void SMS(double amt, double balance)
        {
            Console.WriteLine("SMS:Amount Withdrawn is\t" + amt + "\t and your balance is\t" + balance);
        }

        public static void Email(double amt, double balance)
        {
            Console.WriteLine("Email:Amount Withdrawn is\t" + amt + "\t and your balance is\t" + balance);
        }
    }
}
