﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp11
{
    internal class SavingAccount:Account
    {
        private const double minBal = 1000;
        private const double interest = 0.5;
        public SavingAccount(string name, double bal) : base(name, bal)
        {

        }
        public override void Withdraw(double amt)
        {
            if (amt <= (balance - minBal))
            {
                balance -= amt;
                OnEvent(amt, balance);
            }
            else
            {
                Console.WriteLine("You can withdraw amt greater than\t" + (balance - minBal) + "\t only");

                throw new Exception("Insufficient Balance");
            }
        }
        public double PayInterest(Account a)
        {
            return balance + balance * interest;

        }
    }
}
