﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp11
{
    internal class CurrentAccount:Account
    {
        public CurrentAccount(string name, double bal) : base(name, bal)
        {

        }
        public override void Withdraw(double amt)
        {
            balance -= amt;
            OnEvent(amt, balance);
        }
    }
}
