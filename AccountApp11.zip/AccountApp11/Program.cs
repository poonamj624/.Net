﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Account> list = new List<Account>();

            try
            {
                Account a1 = new CurrentAccount("Shrisha", 10000);
                Account a2 = new SavingAccount("Shriansh", 20000);
                Account a3 = new CurrentAccount("Shri", 30000);
                Account a4 = new SavingAccount("Ira", 40000);
                Account a5 = new CurrentAccount("Ishu", 50000);

                list.Add(a1);
                list.Add(a2);
                list.Add(a3);
                list.Add(a4);
                list.Add(a5);

                a1.me += Message.SMS;
                a2.me += Message.SMS;
                a3.me += Message.SMS;
                a4.me += Message.SMS;
                a5.me += Message.SMS;
                a1.me += Message.Email;
                a2.me += Message.Email;
                a3.me += Message.Email;
                a4.me += Message.Email;
                a5.me += Message.Email;

                a1.Withdraw(6000);
                a2.Withdraw(6000);
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }


        }
    }
}
