﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp11
{
    public delegate void MyDeligate(double amount, double balance);
    abstract internal class Account
    {
        private int AccId;

        public string name;

        public double balance;

        public static int id;

        public Account(string Name, double Balance)
        {
            AccId = ++id;
            if (AccId > 5)
            {
                throw new Exception("More than 5 customers are not allowed");
            }
            else
            {
                name = Name;
                balance = Balance;
            }
        }
        static Account()
        {
            Console.WriteLine("Bank of Baroda");
        }
        public string Name
        {
            get { return name; }

            set
            {
                if (name.Length > 2 && name.Length < 15)
                    name = value;

                else
                    throw new Exception("Invalid Name");
            }
        }
        public double Balance
        {
            get { return balance; }

            protected set { balance = value; }
        }

        public abstract void Withdraw(double amt);

        public void Deposit(double amt)
        {
            balance += amt;
        }

        public event MyDeligate me;

        public void OnEvent(double amt, double balance)
        {
            if (me != null)
            {
                me(amt, balance);
            }
        }

    }
}
