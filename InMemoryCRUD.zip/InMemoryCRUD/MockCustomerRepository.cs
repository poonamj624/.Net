﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace InMemoryCRUD
{
  
    internal class MockCustomerRepository: ICustomerRepository
    {

        private static List<Customer> _customerList;

        public MockCustomerRepository()
        {
            _customerList = new List<Customer>(){
            new Customer() { Id = 1, Name = "shri", Gender = "M" ,Address="pune"},
            new Customer() { Id = 2, Name = "shriansh", Gender = "F" ,Address="pune" },
            new Customer() { Id = 3, Name = "ira",  Gender = "F" ,Address="pune" },
             };
        }
        public Customer Add(Customer customer)
        {
            customer.Id = _customerList.Max(e => e.Id) + 1;
            _customerList.Add(customer);
            return customer;
        }
        public Customer Delete(int Id)
        {
            Customer customer = _customerList.FirstOrDefault(e => e.Id == Id);
            if (customer != null)
            {
                _customerList.Remove(customer);
            }
            return customer;
        }
        public IEnumerable<Customer> GetAllCustomer()
        {
            return _customerList;
        }
        public Customer GetCustomer(int Id)
        {
            return _customerList.FirstOrDefault(e => e.Id == Id);
       }
        
        public Customer Update(Customer customerChanges)
        {
            Customer customer = _customerList.FirstOrDefault(e => e.Id == customerChanges.Id);
            if (customer != null)
            {
                customer.Name = customerChanges.Name;
               // customer.Salary = customerChanges.Salary;
                customer.Gender = customerChanges.Gender;
                customer.Address = customerChanges.Address;
            }
            return customer;
        }
    }

}

