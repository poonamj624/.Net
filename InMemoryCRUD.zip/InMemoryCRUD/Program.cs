﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace InMemoryCRUD
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MockCustomerRepository db = new MockCustomerRepository();
            Display(db);
            Customer a = db.Add(new Customer { Name = "Kavita", Gender = "M", Address = "pune" });
            Console.WriteLine("Record Added: {0} {1} {2}", a.Id, a.Name, a.Gender,a.Address);
            Display(db);
            db.Delete(4);
            Display(db);
           Customer m = new Customer { Id = 3, Name = "Sam", Gender = "F", Address = "pune" };
           
            UpdateData(m, db);


        }
        static void Display(MockCustomerRepository db)
        {
            foreach (Customer a in db.GetAllCustomer())
                Console.WriteLine(": {0} {1} {2} {3}", a.Id, a.Name,a.Gender, a.Address);
        }
        
        static void UpdateData(Customer e, MockCustomerRepository db)
        {
            db.Update(e);
            Display(db);
        }
    }
}
