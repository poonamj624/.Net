﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InMemoryCRUD
{
    internal class Customer
    {
        internal string Gender;

        public int Id { get; set; }
        public string Name { get; set; }
      //  public int Salary { get; set; }
        public string Gerder { get; set; }
        public string Address { get; set; }

    }
}
